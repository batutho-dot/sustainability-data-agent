# eurostat-mcp

An MCP server that lets Claude (or any MCP client) look up public Eurostat statistics:
search the catalogue, see a dataset's dimensions, fetch a filtered series. Two energy series
are also offered as ready-made resources: renewable energy share and household electricity
prices, per country.

## The question

Can an AI assistant answer factual questions about European energy statistics correctly if
it gets the official numbers through a small server, instead of from memory? Measured on 10
questions whose right answers a plain script computes from the same Eurostat API.

## Result

| Run | Model | Score | Cost (reported by Claude Code) |
|---|---|---|---|
| Claude Code with this server, no other tools | Sonnet (`--model sonnet`) | **10/10** | 0.155 USD |
| Same model, no tools, from memory | Sonnet (`--model sonnet`) | **3/10** | 0.085 USD |

Run on 2026-11-19, one run per question, no retries. Numbers are matched within a stated
tolerance (0.01 percentage points for shares, 0.0001 EUR/kWh for prices); codes must match
exactly. Every tool call and tool result is saved in `eval/results/mcp/*.jsonl`, the
summary with tokens and time per question in `eval/results/mcp.json`.

Tool calls the agent made:

| Q | Asked | Expected | Calls |
|---|---|---|---|
| q01 | Denmark, renewable share 2022 (%) | 41.368 | fetch_series |
| q02 | Sweden, renewable share in electricity 2023 (%) | 87.547 | describe_dataset, fetch_series |
| q03 | EU state with highest renewable share 2023 | SE | describe_dataset, fetch_series x2 |
| q04 | EU27 renewable share 2024 (%) | 25.241 | fetch_series |
| q05 | Denmark household electricity price 2024-S1, band DC, all taxes (EUR/kWh) | 0.3708 | describe_dataset, fetch_series |
| q06 | Germany 2023, mean of both half-years, same filters | 0.4073 | fetch_series |
| q07 | Denmark renewable share change 2015 to 2023 (pp) | 13.259 | fetch_series |
| q08 | EU state with lowest household price 2025-S1, band DC, all taxes | HU | describe_dataset, fetch_series |
| q09 | France 2024-S2, band DC, excluding taxes (EUR/kWh) | 0.2223 | describe_dataset, fetch_series |
| q10 | Dataset code for household gas prices, bi-annual | nrg_pc_202 | search_datasets |

From memory the model got the three questions with a stable, well-known answer (q03, q08,
q10). It came close but missed on shares (41.6 for 41.368, 25.2 for 25.241, 14.0 for 13.259,
75.8 for 87.547) and said "unknown" for all three prices.

## How to run

Needs Python 3.10 or newer and Claude Code.

```bash
git clone https://github.com/batutho-dot/eurostat-mcp && cd eurostat-mcp
python -m venv .venv && .venv/Scripts/pip install -e .      # macOS/Linux: .venv/bin/pip
claude mcp add eurostat -- "$(pwd)/.venv/Scripts/eurostat-mcp"   # macOS/Linux: .venv/bin/eurostat-mcp
```

Then ask Claude Code something like "What was Denmark's renewable energy share in 2022?".
No API key is needed; Eurostat's API is open.

## What the server offers

Tools are things the model decides to call. Resources are fixed, addressed data the app can
load and put in front of the model.

| Kind | Name | What it does |
|---|---|---|
| Tool | `search_datasets(query)` | Searches the Eurostat catalogue titles; returns code, title, time coverage, last update |
| Tool | `describe_dataset(dataset)` | Lists the dimensions of a dataset and the codes each takes, so filters can be chosen |
| Tool | `fetch_series(dataset, filters, since, until, last)` | Returns the filtered values, one row per value, with labels and Eurostat's status flags |
| Resource | `eurostat://datasets` | The named datasets below, with their codes and filters |
| Resource | `eurostat://renewable-share/{geo}` | `nrg_ind_ren`, `nrg_bal=REN`, `unit=PC`: overall renewable share, annual, percent |
| Resource | `eurostat://household-electricity-price/{geo}` | `nrg_pc_204`, `nrg_cons=KWH2500-4999` (band DC), `tax=I_TAX`, `currency=EUR`, `unit=KWH`: half-yearly values plus an annual mean |

The annual mean in the price resource is computed here, not by Eurostat: the mean of S1 and
S2, given only for years where both halves are reported.

## How it is built

Claude talks to the server over stdio. The server's tools and resources use a small Eurostat
client that downloads the catalogue or a filtered dataset and decodes the JSON-stat answer
into rows. Boxes are parts of the two source files, with keywords for what each one does.
The sequence of one request and a table linking each box to a file and line are in
[docs/architecture.md](docs/architecture.md).

```mermaid
flowchart LR
    client["Claude (MCP client)<br/>asks a question, picks a tool or resource, reads the JSON"]
    sdk["MCP Python SDK<br/>MCPServer, stdio, tool and resource registry, ToolError"]
    tools["server.py: tools<br/>search_datasets, describe_dataset, fetch_series"]
    res["server.py: resources<br/>NAMED datasets, renewable share, household price, annual mean"]
    cat["eurostat.py: catalogue<br/>load_toc, search, in-memory cache"]
    http["eurostat.py: HTTP<br/>_get, fetch, filters, EurostatError"]
    dec["eurostat.py: JSON-stat decoding<br/>to_rows, labels, row-major index, status flags"]
    ext["Eurostat dissemination API<br/>statistics JSON-stat, catalogue table of contents"]
    tests["tests/test_server.py<br/>pytest, in-memory client, live API, 6 tests"]

    client -->|"stdio: tool call or resource read"| sdk
    sdk -->|"runs the tool function"| tools
    sdk -->|"runs the resource function"| res
    tools -->|"search, load_toc"| cat
    tools -->|"fetch"| http
    tools -->|"to_rows, labels"| dec
    res -->|"fetch"| http
    res -->|"to_rows"| dec
    cat -->|"_get"| http
    http -->|"HTTPS GET"| ext
    tests -->|"in-memory Client"| sdk
    tests -.->|"calls to_rows directly"| dec

    classDef outside fill:#eee,stroke:#888,stroke-dasharray: 4 3
    class client,ext outside
```

## Test set

- `eval/questions.json`: the 10 questions and the tolerance for each.
- `eval/reference.py`: computes the right answers. Standard library only, with its own
  JSON-stat decoding, so it shares no code with the server it checks. Writes
  `eval/expected.json`.
- `eval/run_eval.py --mode mcp` / `--mode none`: asks Claude Code each question in a fresh
  headless session (`claude -p`), with only this server's tools, or with no tools. User
  settings and hooks are switched off for the run (`--setting-sources project`).
- `tests/`: 6 pytest tests through an in-memory MCP client (`pip install -e ".[dev]"`, then
  `pytest`). They call the live API.

```bash
python eval/reference.py && python eval/run_eval.py --mode mcp
```

## What did not work

- The first baseline run gave the model no tools but did not say so. It wrote out shell
  commands it could not run and gave no answer to the first three questions, so the run was
  stopped. The prompt for the no-tools run now says plainly that there are no tools. Only
  the second run is reported.
- A tool that returned a Python list came back to the model as one message per item; the
  search tool now returns one object with a `results` list.
- The European Environment Agency's data service (Discodata) answered 403 Forbidden to a
  plain request on 2026-11-19, so EEA data is not included.
- In the 10-question eval the agent never used the resources; it went straight to the tools.
  The resources work (a separate check read `eurostat://renewable-share/DK` and returned the
  2020 value, 31.681), but an agent answering a question prefers tools. In Claude Code you
  attach a resource yourself with `@`.

## Limits

- 10 questions, one run each, one model. A score of 10/10 says the server returns the right
  numbers for these questions; it does not say the agent will always pick the right filters.
- Answers depend on the data on the day. Eurostat revises data, so `expected.json` must be
  recomputed before a rerun, and an old score may not reproduce exactly.
- `describe_dataset` reads the latest period of the whole dataset to list its codes. For a
  very large dataset that can be slow or refused by Eurostat; filter first in that case.
- Search matches title words only, in English.
- Only the Eurostat statistics API (JSON-stat). Comext and Prodcom data use a different host
  and are not covered.

## Sources and credit

Data: **Eurostat**, datasets `nrg_ind_ren` (Share of renewable energy, updated 2026-09-15)
and `nrg_pc_204` (Electricity prices for household consumers, bi-annual data, updated
2026-10-19), plus the catalogue table of contents. Eurostat allows reuse of its statistical
data, commercial or not, provided the source is acknowledged
([copyright notice](https://ec.europa.eu/eurostat/web/main/help/copyright-notice)). This
project changes the data in one way: the annual mean of the two half-year prices. Eurostat
bears no responsibility for this project or for any use of it.

- Statistics API: <https://ec.europa.eu/eurostat/web/user-guides/data-browser/api-data-access/api-detailed-guidelines/api-statistics>
- Catalogue table of contents: <https://ec.europa.eu/eurostat/api/dissemination/catalogue/toc/txt?lang=en>
- MCP Python SDK (version 2.3.0): <https://py.sdk.modelcontextprotocol.io/>
