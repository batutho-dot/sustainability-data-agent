"""Small client for Eurostat's public dissemination API.

Two endpoints are used, both documented by Eurostat:

- Statistics API (JSON-stat 2.0):
  https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/{dataset}?{filters}
- Catalogue table of contents (tab-separated text):
  https://ec.europa.eu/eurostat/api/dissemination/catalogue/toc/txt?lang=en

No API key is needed.
"""

from __future__ import annotations

import csv
import io
from typing import Any

import httpx

BASE = "https://ec.europa.eu/eurostat/api/dissemination"
DATA_URL = BASE + "/statistics/1.0/data/{code}"
TOC_URL = BASE + "/catalogue/toc/txt?lang=en"
TIMEOUT = httpx.Timeout(60.0)

_toc_cache: list[dict[str, str]] | None = None


class EurostatError(Exception):
    """Eurostat answered with an error or with something this client cannot read."""


def _get(url: str, params: list[tuple[str, str]] | None = None) -> httpx.Response:
    with httpx.Client(timeout=TIMEOUT, follow_redirects=True) as client:
        response = client.get(url, params=params)
    if response.status_code != 200:
        detail = response.text[:300]
        try:
            body = response.json()
            detail = body.get("error", [{}])[0].get("label", detail) if isinstance(body.get("error"), list) else str(body.get("error", detail))
        except ValueError:
            pass
        raise EurostatError(f"Eurostat returned HTTP {response.status_code}: {detail}")
    return response


def load_toc() -> list[dict[str, str]]:
    """Download the catalogue once per process and keep it in memory."""
    global _toc_cache
    if _toc_cache is None:
        text = _get(TOC_URL).text
        reader = csv.reader(io.StringIO(text), delimiter="\t")
        header = next(reader)
        rows = []
        for raw in reader:
            row = dict(zip(header, raw))
            if row.get("type") not in ("dataset", "table"):
                continue
            rows.append(
                {
                    "code": row["code"].strip(),
                    "title": row["title"].strip(),
                    "type": row["type"],
                    "last_update": row.get("last update of data", "").strip(),
                    "data_start": row.get("data start", "").strip(),
                    "data_end": row.get("data end", "").strip(),
                }
            )
        _toc_cache = rows
    return _toc_cache


def search(query: str, limit: int = 20) -> list[dict[str, str]]:
    """Datasets whose title or code contains every word of the query (case-insensitive)."""
    words = [w for w in query.lower().split() if w]
    seen: set[str] = set()
    hits = []
    for row in load_toc():
        haystack = (row["title"] + " " + row["code"]).lower()
        if row["code"] in seen or not all(w in haystack for w in words):
            continue
        seen.add(row["code"])
        hits.append(row)
        if len(hits) >= limit:
            break
    return hits


def fetch(code: str, filters: dict[str, list[str]] | None = None, **time: str | int | None) -> dict[str, Any]:
    """Raw JSON-stat 2.0 response for a dataset, filtered on the server side.

    `time` takes Eurostat's own time parameters: sinceTimePeriod, untilTimePeriod,
    lastTimePeriod. Only one of them, or since and until together, may be used.
    """
    params: list[tuple[str, str]] = [("format", "JSON"), ("lang", "EN")]
    for dim, values in (filters or {}).items():
        for value in values:
            params.append((dim, value))
    for key, value in time.items():
        if value is not None:
            params.append((key, str(value)))
    data = _get(DATA_URL.format(code=code), params).json()
    if data.get("class") != "dataset":
        raise EurostatError(f"Unexpected response for {code}: {str(data)[:300]}")
    return data


def to_rows(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Flatten a JSON-stat 2.0 dataset into one dict per value.

    JSON-stat stores values in a flat array in row-major order over the
    dimensions listed in `id` with lengths in `size`; `value` may be a dict
    keyed by the flat index when the cube is sparse.
    """
    ids: list[str] = data["id"]
    sizes: list[int] = data["size"]
    positions = []
    for dim in ids:
        index = data["dimension"][dim]["category"]["index"]
        by_pos = sorted(index.items(), key=lambda kv: kv[1]) if isinstance(index, dict) else [(c, i) for i, c in enumerate(index)]
        positions.append([code for code, _ in by_pos])

    values = data.get("value", {})
    if isinstance(values, list):
        values = {str(i): v for i, v in enumerate(values) if v is not None}
    statuses = data.get("status", {}) or {}
    if isinstance(statuses, list):
        statuses = {str(i): s for i, s in enumerate(statuses) if s}

    strides = [1] * len(sizes)
    for i in range(len(sizes) - 2, -1, -1):
        strides[i] = strides[i + 1] * sizes[i + 1]

    rows = []
    for flat_str, value in values.items():
        flat = int(flat_str)
        row: dict[str, Any] = {}
        for dim, stride, size, codes in zip(ids, strides, sizes, positions):
            row[dim] = codes[(flat // stride) % size]
        row["value"] = value
        if flat_str in statuses:
            row["status"] = statuses[flat_str]
        rows.append(row)
    rows.sort(key=lambda r: [r[d] for d in ids])
    return rows


def labels(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Dimension labels and category labels, for codes present in the response."""
    out = {}
    for dim in data["id"]:
        d = data["dimension"][dim]
        out[dim] = {"label": d.get("label", dim), "categories": d["category"].get("label", {})}
    return out
