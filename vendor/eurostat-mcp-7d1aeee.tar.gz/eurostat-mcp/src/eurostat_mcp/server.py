"""Eurostat MCP server.

Tools are things the model decides to call (search, describe, fetch).
Resources are fixed, named datasets the app can load as context.
"""

from __future__ import annotations

import json
from typing import Annotated, Any

from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from pydantic import Field

from eurostat_mcp import eurostat

mcp = MCPServer(
    "eurostat",
    instructions=(
        "Public Eurostat statistics. Find a dataset code with search_datasets, see its "
        "dimensions and codes with describe_dataset, then get numbers with fetch_series. "
        "Two ready-made series are also available as resources: renewable energy share and "
        "household electricity prices, per country. Values come from Eurostat; say which "
        "dataset and filters an answer used."
    ),
)

MAX_CATEGORIES = 60

# The named datasets behind the resources. Every code below was checked against
# the live API on 2026-11-19 (see README, "Sources").
NAMED = {
    "renewable-share": {
        "dataset": "nrg_ind_ren",
        "title": "Share of renewable energy in gross final energy consumption, overall",
        "filters": {"nrg_bal": ["REN"], "unit": ["PC"]},
        "unit": "percent",
        "frequency": "annual",
    },
    "household-electricity-price": {
        "dataset": "nrg_pc_204",
        "title": "Electricity price for household consumers, band DC (2 500 to 4 999 kWh a year), all taxes and levies included",
        "filters": {
            "nrg_cons": ["KWH2500-4999"],
            "tax": ["I_TAX"],
            "currency": ["EUR"],
            "unit": ["KWH"],
        },
        "unit": "EUR per kWh",
        "frequency": "half-yearly (S1, S2); annual value = mean of S1 and S2, only when both halves are reported",
    },
}


def _fail(exc: Exception) -> ToolError:
    return ToolError(str(exc))


@mcp.tool()
def search_datasets(
    query: Annotated[str, Field(description="Words that must all appear in the dataset title or code, e.g. 'gas prices household'.")],
    limit: Annotated[int, Field(ge=1, le=50)] = 15,
) -> dict[str, Any]:
    """Search Eurostat's catalogue of datasets by title words. Returns code, title, time coverage and last update."""
    try:
        hits = eurostat.search(query, limit)
    except eurostat.EurostatError as exc:
        raise _fail(exc) from exc
    if not hits:
        raise ToolError(f"No Eurostat dataset title contains all of: {query!r}. Try fewer or broader words.")
    return {"query": query, "n_results": len(hits), "results": hits}


@mcp.tool()
def describe_dataset(
    dataset: Annotated[str, Field(description="Eurostat dataset code, e.g. 'nrg_pc_204'.")],
) -> dict[str, Any]:
    """List a dataset's dimensions and the codes each one takes (from its latest period), so filters for fetch_series can be chosen."""
    try:
        data = eurostat.fetch(dataset, lastTimePeriod=1)
    except eurostat.EurostatError as exc:
        raise _fail(exc) from exc
    dims = {}
    for dim, info in eurostat.labels(data).items():
        cats = info["categories"]
        shown = dict(list(cats.items())[:MAX_CATEGORIES])
        dims[dim] = {"label": info["label"], "n_codes": len(cats), "codes": shown}
        if len(cats) > MAX_CATEGORIES:
            dims[dim]["note"] = f"first {MAX_CATEGORIES} of {len(cats)} codes shown"
    toc = next((r for r in eurostat.load_toc() if r["code"].lower() == dataset.lower()), None)
    return {
        "dataset": dataset,
        "title": data.get("label"),
        "updated": data.get("updated"),
        "coverage": {"start": toc["data_start"], "end": toc["data_end"]} if toc else None,
        "dimensions": dims,
        "note": "The 'time' dimension above shows only the latest period; use coverage for the full range.",
    }


@mcp.tool()
def fetch_series(
    dataset: Annotated[str, Field(description="Eurostat dataset code, e.g. 'nrg_ind_ren'.")],
    filters: Annotated[
        dict[str, list[str]],
        Field(description="Dimension code -> list of category codes, e.g. {'geo': ['DK','SE'], 'nrg_bal': ['REN']}. Unfiltered dimensions return all codes."),
    ] = {},
    since: Annotated[str | None, Field(description="First period, e.g. '2015' or '2020-S1'.")] = None,
    until: Annotated[str | None, Field(description="Last period, e.g. '2023' or '2024-S2'.")] = None,
    last: Annotated[int | None, Field(ge=1, le=50, description="Only the latest N periods. Do not combine with since/until.")] = None,
    max_rows: Annotated[int, Field(ge=1, le=2000)] = 500,
) -> dict[str, Any]:
    """Fetch filtered values from a Eurostat dataset. Returns one row per value with dimension codes, plus labels for the codes."""
    if last is not None and (since or until):
        raise ToolError("Use either 'last' or 'since'/'until', not both.")
    try:
        data = eurostat.fetch(
            dataset,
            filters,
            sinceTimePeriod=since,
            untilTimePeriod=until,
            lastTimePeriod=last,
        )
    except eurostat.EurostatError as exc:
        raise _fail(exc) from exc
    rows = eurostat.to_rows(data)
    # Dimensions with a single code carry no information per row; report them once.
    fixed = {dim: next(iter(info["categories"]), None) for dim, info in eurostat.labels(data).items() if len(info["categories"]) == 1}
    slim = [{k: v for k, v in row.items() if k not in fixed} for row in rows[:max_rows]]
    return {
        "dataset": dataset,
        "title": data.get("label"),
        "updated": data.get("updated"),
        "same_for_all_rows": fixed,
        "labels": {dim: info["categories"] for dim, info in eurostat.labels(data).items()},
        "n_rows": len(rows),
        "truncated": len(rows) > max_rows,
        "rows": slim,
        "status_flags": "b=break in series, e=estimated, p=provisional, c=confidential, d=definition differs, u=low reliability",
    }


def _named_series(key: str, geo: str) -> dict[str, Any]:
    spec = NAMED[key]
    filters = dict(spec["filters"], geo=[geo.upper()])
    data = eurostat.fetch(spec["dataset"], filters)
    rows = eurostat.to_rows(data)
    series = {row["time"]: row["value"] for row in rows}
    out: dict[str, Any] = {
        "dataset": spec["dataset"],
        "title": spec["title"],
        "geo": geo.upper(),
        "unit": spec["unit"],
        "frequency": spec["frequency"],
        "filters": filters,
        "updated": data.get("updated"),
        "source": "Eurostat, " + spec["dataset"],
    }
    if key == "household-electricity-price":
        annual = {}
        years = sorted({t.split("-")[0] for t in series})
        for year in years:
            s1, s2 = series.get(f"{year}-S1"), series.get(f"{year}-S2")
            if s1 is not None and s2 is not None:
                annual[year] = round((s1 + s2) / 2, 4)
        out["half_yearly"] = series
        out["annual_mean"] = annual
    else:
        out["annual"] = series
    return out


@mcp.resource("eurostat://datasets", mime_type="application/json")
def named_datasets() -> str:
    """The named datasets this server offers as resources, with their Eurostat codes and filters."""
    return json.dumps(
        {key: dict(spec, uri=f"eurostat://{key}/{{geo}}") for key, spec in NAMED.items()},
        indent=2,
    )


@mcp.resource("eurostat://renewable-share/{geo}", mime_type="application/json")
def renewable_share(geo: str) -> str:
    """Annual share of renewable energy (overall, percent) for one country code, e.g. DK, or EU27_2020."""
    return json.dumps(_named_series("renewable-share", geo), indent=2)


@mcp.resource("eurostat://household-electricity-price/{geo}", mime_type="application/json")
def household_electricity_price(geo: str) -> str:
    """Household electricity price, band DC, all taxes included, EUR/kWh, half-yearly and annual mean, for one country code."""
    return json.dumps(_named_series("household-electricity-price", geo), indent=2)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
