"""MCP server for public Eurostat statistics."""
